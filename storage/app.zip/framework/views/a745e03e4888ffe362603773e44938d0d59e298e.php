<div class="grid grid-cols-4 gap-4 pt-4">
    <div class="col-span-4 lg:col-span-1">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card.base','data' => []]); ?>
<?php $component->withName('card.base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
            <p class="text-xl font-bold">Kategori</p>
                <div class="flex flex-col pl-4 mt-4">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="flex mt-4">
                            <?php if($category->id==$selectedCategoryId): ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.anchor.black','data' => ['class' => 'grow','href' => '#']]); ?>
<?php $component->withName('anchor.black'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'grow','href' => '#']); ?>
                                    <?php echo e($category->name); ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php else: ?>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.anchor.white','data' => ['class' => 'grow','href' => ''.e(route('kategori', ['id' => $category->id])).'']]); ?>
<?php $component->withName('anchor.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'grow','href' => ''.e(route('kategori', ['id' => $category->id])).'']); ?>
                                    <?php echo e($category->name); ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php endif; ?>

                            <?php if(auth()->guard()->check()): ?>
                                <div x-data="{ open: false }" class="relative ml-2">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['@click' => 'open = true']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['@click' => 'open = true']); ?>
                                        <i class="fas fa-ellipsis-h"></i>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                    <ul x-show="open" @click.away="open = false" class="bg-white border border-gray-300 rounded absolute z-10 p-2">
                                        <li><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'category-modal\', '.e(json_encode(['id' => $category->id])).')']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'category-modal\', '.e(json_encode(['id' => $category->id])).')']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></li>
                                        <li class="mt-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.error','data' => ['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'category-delete-modal\', '.e(json_encode(['id' => $category->id])).')']]); ?>
<?php $component->withName('button.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'category-delete-modal\', '.e(json_encode(['id' => $category->id])).')']); ?>Hapus <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></li>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="font-bold text-center mb-0">Belum ada kategori.</p>
                    <?php endif; ?>
                </div>

            <?php if(auth()->guard()->check()): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.success','data' => ['class' => 'mt-10','wire:click' => '$emit(\'openModal\', \'category-modal\', '.e(json_encode(['id' => ''])).')']]); ?>
<?php $component->withName('button.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-10','wire:click' => '$emit(\'openModal\', \'category-modal\', '.e(json_encode(['id' => ''])).')']); ?>+ Kategori <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <div class="col-span-4 lg:col-span-3">
        <?php if(!empty($selectedCategoryId)): ?>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('subcategory', ['categoryId' => $selectedCategoryId, 'year' => $year, 'villageId' => $villageId])->html();
} elseif ($_instance->childHasBeenRendered('l4096779302-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4096779302-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4096779302-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4096779302-0');
} else {
    $response = \Livewire\Livewire::mount('subcategory', ['categoryId' => $selectedCategoryId, 'year' => $year, 'villageId' => $villageId]);
    $html = $response->html();
    $_instance->logRenderedChild('l4096779302-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/livewire/dashboard.blade.php ENDPATH**/ ?>