<div class="my-2 mx-2">
    <div class="flex justify-between items-center px-4 sm:px-0">
        <?php if(isset($title)): ?>
            <h4 class="mb-2 flex-1 text-xl font-semibold text-gray-800 dark:text-gray-300 capitalize">
                <?php echo e($title); ?>

            </h4>
        <?php endif; ?>
        <?php if(isset($aside)): ?>
            <div class="mb-2 ">
                <?php echo e($aside); ?>

            </div>
        <?php endif; ?>
    </div>
    <div
        <?php echo e($attributes->merge(['class' => 'px-4 py-5 sm:p-6 bg-white sm:rounded-lg shadow-md border border-gray-100 text-gray-800'])); ?>>
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/card/base.blade.php ENDPATH**/ ?>