<div <?php echo e($attributes->merge(['class' => 'mb-3 mt-3'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/input/wrapper.blade.php ENDPATH**/ ?>