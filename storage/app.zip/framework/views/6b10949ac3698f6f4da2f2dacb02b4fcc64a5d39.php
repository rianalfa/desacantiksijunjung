<div class="space-y-6 leading-relaxed text-gray-800 pt-2 pb-3 pl-10 pr-5">
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/modal/body.blade.php ENDPATH**/ ?>