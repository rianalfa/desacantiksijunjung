<span
    <?php echo e($attributes->merge(['class' => 'inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-green-600 bg-green-200 rounded-full'])); ?>>
    <?php echo e($slot); ?>

</span>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/badge/success.blade.php ENDPATH**/ ?>