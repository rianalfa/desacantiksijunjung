<div class="flex justify-between items-center rounded-t px-5 pt-5">
    <p class="text-lg font-bold text-gray-900 lg:text-xl dark:text-white">
        <?php echo e($slot); ?>

    </p>
</div>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/modal/header.blade.php ENDPATH**/ ?>