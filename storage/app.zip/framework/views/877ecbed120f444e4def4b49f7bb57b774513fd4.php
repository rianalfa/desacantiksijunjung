<label <?php echo e($attributes->merge(['class' => 'block font-medium text-sm text-gray-800'])); ?>>
  <?php echo e($value); ?>

</label>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/input/label.blade.php ENDPATH**/ ?>