<div class="uppercase font-bold text-xl">
    Sijunjung
</div>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/logo/text.blade.php ENDPATH**/ ?>