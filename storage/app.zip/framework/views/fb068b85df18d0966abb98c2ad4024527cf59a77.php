<div
    <?php echo e($attributes->merge(['class' => "flex items-center space-x-2 rounded-b bg-gray-100 py-3 px-5"])); ?>

    >
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/modal/footer.blade.php ENDPATH**/ ?>