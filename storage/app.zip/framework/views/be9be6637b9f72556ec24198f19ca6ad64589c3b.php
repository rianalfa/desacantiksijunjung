<?php $attributes = $attributes->exceptProps(['menu' => 'Menu Item', 'active' => false]); ?>
<?php foreach (array_filter((['menu' => 'Menu Item', 'active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a <?php echo e($attributes->merge(['href'])); ?> class="<?php echo \Illuminate\Support\Arr::toCssClasses([
    'border-sky-700 font-bold' => $active,
    'hover:text-sky-500 border-white hover:border-sky-500 cursor-pointer font-medium ' => !$active,
    'flex items-center border-b-2 px-3 text-gray-800 ',
]) ?>"><?php echo e($menu); ?></a>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/components/header/item.blade.php ENDPATH**/ ?>