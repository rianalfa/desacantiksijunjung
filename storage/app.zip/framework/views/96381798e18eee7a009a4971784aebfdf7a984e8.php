<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card.full','data' => []]); ?>
<?php $component->withName('card.full'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <p class="text-xl text-center font-bold">Kategori <?php echo e($category->name); ?></p>
    <div class="flex flex-col lg:flex-row lg:justify-between">
        <div class="inline-flex">
            <?php if($table==false): ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['wire:click' => 'changeTable(false)','class' => 'rounded-r-none']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'changeTable(false)','class' => 'rounded-r-none']); ?><?php echo e(__('Card')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.black','data' => ['wire:click' => 'changeTable(true)','class' => 'rounded-l-none']]); ?>
<?php $component->withName('button.black'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'changeTable(true)','class' => 'rounded-l-none']); ?><?php echo e(__('Table')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.black','data' => ['wire:click' => 'changeTable(false)','class' => 'rounded-r-none']]); ?>
<?php $component->withName('button.black'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'changeTable(false)','class' => 'rounded-r-none']); ?><?php echo e(__('Card')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['wire:click' => 'changeTable(true)','class' => 'rounded-l-none']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => 'changeTable(true)','class' => 'rounded-l-none']); ?><?php echo e(__('Table')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="flex flex-col lg:flex-row">
            <?php if($table==false): ?>
                <div class="flex items-center">
                    <div x-data="{ open: false }" class="relative">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['@click' => 'open = true']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['@click' => 'open = true']); ?>Desa <?php echo e($village->name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card.base','data' => ['xShow' => 'open','@click.outside' => 'open = false','class' => 'absolute top-10 right-0 z-50']]); ?>
<?php $component->withName('card.base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-show' => 'open','@click.outside' => 'open = false','class' => 'absolute top-10 right-0 z-50']); ?>
                            <div class="flex flex-col w-48 max-h-40 overflow-y-auto">
                                <?php $__empty_1 = true; $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <a href="<?php echo e(route('kategori', ['id' => $category->id, 'year' => $year, 'villageId' => $v->id])); ?>"><?php echo e($v->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div></div>
                                <?php endif; ?>
                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <?php if(auth()->guard()->check()): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.success','data' => ['wire:click' => '$emit(\'openModal\', \'bankers-excel-modal\', '.e(json_encode(['year' => $year])).')']]); ?>
<?php $component->withName('button.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['wire:click' => '$emit(\'openModal\', \'bankers-excel-modal\', '.e(json_encode(['year' => $year])).')']); ?>
                        Data Excel
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>

            <div class="flex items-center lg:ml-4">
                <div x-data="{ open: false }" class="relative">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['@click' => 'open = true']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['@click' => 'open = true']); ?><?php echo e($year); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card.base','data' => ['xShow' => 'open','@click.outside' => 'open = false','class' => 'absolute top-10 left-0 z-50']]); ?>
<?php $component->withName('card.base'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-show' => 'open','@click.outside' => 'open = false','class' => 'absolute top-10 left-0 z-50']); ?>
                        <a href="<?php echo e(route('kategori', ['id' => $category->id, 'year' => '2018'])); ?>">2018</a>
                        <a href="<?php echo e(route('kategori', ['id' => $category->id, 'year' => '2019'])); ?>">2019</a>
                        <a href="<?php echo e(route('kategori', ['id' => $category->id, 'year' => '2020'])); ?>">2020</a>
                        <a href="<?php echo e(route('kategori', ['id' => $category->id, 'year' => '2021'])); ?>">2021</a>
                        <a href="<?php echo e(route('kategori', ['id' => $category->id, 'year' => '2022'])); ?>">2022</a>
                        <a href="<?php echo e(route('kategori', ['id' => $category->id, 'year' => '2023'])); ?>">2023</a>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
        <?php if($table==false): ?>
            <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-span-1">
                    <div x-data="{ open: false }" class="flex justify-center relative">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['class' => 'w-full py-6 z-10','@click' => 'open = true']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full py-6 z-10','@click' => 'open = true']); ?>
                            <p class="font-bold"><?php echo e($subcategory->name); ?></p>
                            <img src="<?php echo e(asset('storage/images/subcategory/'.$subcategory->id.'.png')); ?>" alt="."
                                class="w-32 h-32 object-contain mx-auto">
                            <?php
                                $banker = $subcategory->bankers()
                                                    ->where('village_id', $village->id)
                                                    ->where('year', $year)
                                                    ->first();
                                echo !empty($banker) ? $banker->value : '-'
                            ?>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                        <?php if(auth()->guard()->check()): ?>
                            <ul x-show="open" @click.away="open = false" class="bg-white border border-gray-300 rounded absolute top-8 z-20 p-2">
                                <li><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'subcategory-modal\', '.e(json_encode(['id' => $subcategory->subcategory_id, 'categoryId' => $category->id])).')']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'subcategory-modal\', '.e(json_encode(['id' => $subcategory->subcategory_id, 'categoryId' => $category->id])).')']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></li>
                                <li class="mt-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.white','data' => ['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'banker-modal\', '.e(json_encode([
                                        'id' => !empty($banker) ? $banker->id : '',
                                        'villageId' => $village->id,
                                        'subcategoryId' => $subcategory->id,
                                        'year' => $year,
                                    ])).')']]); ?>
<?php $component->withName('button.white'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'banker-modal\', '.e(json_encode([
                                        'id' => !empty($banker) ? $banker->id : '',
                                        'villageId' => $village->id,
                                        'subcategoryId' => $subcategory->id,
                                        'year' => $year,
                                    ])).')']); ?>Data <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></li>
                                <li class="mt-2"><?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.error','data' => ['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'subcategory-delete-modal\', '.e(json_encode(['id' => $subcategory->id])).')']]); ?>
<?php $component->withName('button.error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full px-2 py-1','wire:click' => '$emit(\'openModal\', \'subcategory-delete-modal\', '.e(json_encode(['id' => $subcategory->id])).')']); ?>Hapus <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?></li>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="font-bold text-center mb-0">Belum ada subkategori.</p>
            <?php endif; ?>
        <?php else: ?>
            <?php if(!empty($subcategories)): ?>
                <div class="flex flex-col col-span-4">
                    <div class="overflow-x-auto">
                        <div class="inline-block py-2 min-w-full px-2">
                            <div class="overflow-hidden shadow-md sm:rounded-lg">
                                <table class="table-auto min-w-full overflow-x-auto">
                                    <thead class="bg-gray-100 rounded-t-md">
                                        <tr class="flex pr-4">
                                            <th scope='col' class='text-xs font-medium tracking-wider text-center text-gray-700 w-20 py-3 px-6 uppercase'>No</th>
                                            <th scope='col' class='grow-1 text-xs font-medium tracking-wider text-center text-gray-700 w-72 py-3 px-6 uppercase'>Desa</th>
                                            <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th scope='col' class='text-xs font-medium tracking-wider text-center text-gray-700 w-28 py-3 px-6 uppercase'><?php echo e($subcategory->name); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(auth()->guard()->check()): ?>
                                                <th scope='col' class='text-xs font-medium tracking-wider text-center text-gray-700 w-28 py-3 px-6 uppercase'>Action</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody class="flex flex-col max-h-80 overflow-y-auto">
                                        <?php $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="flex bg-white border-b w-full">
                                                <td class="text-sm text-gray-500 text-center whitespace-nowrap border-r w-20 py-4 px-6"><?php echo e($i+1); ?></td>
                                                <td class="grow-1 text-sm text-gray-500 font-bold whitespace-nowrap border-r w-72 py-4 px-6"><?php echo e($v->name); ?></td>
                                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <td class="text-sm text-gray-500 text-right whitespace-nowrap border-r w-28 py-4 px-6">
                                                        <?php
                                                            $value = $subcategory->bankers()
                                                                                ->where('village_id', $v->id)
                                                                                ->where('year', $year)
                                                                                ->first();
                                                            $value = !empty($value) ? $value->value : '-';
                                                            echo $value;
                                                        ?>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(auth()->guard()->check()): ?>
                                                    <td class="text-sm text-gray-500 text-center whitespace-nowrap border-r w-28 py-4 px-6">
                                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.badge.success','data' => ['class' => 'cursor-pointer','wire:click' => '$emit(\'openModal\', \'bankers-modal\', '.e(json_encode([
                                                                'villageId' => $v->id,
                                                                'categoryId' => $category->id,
                                                                'year' => $year,
                                                            ])).')']]); ?>
<?php $component->withName('badge.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'cursor-pointer','wire:click' => '$emit(\'openModal\', \'bankers-modal\', '.e(json_encode([
                                                                'villageId' => $v->id,
                                                                'categoryId' => $category->id,
                                                                'year' => $year,
                                                            ])).')']); ?>edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <p class="font-bold text-center mb-0">Belum ada subkategori.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php if($table==false): ?>
        <div class="flex justify-center h-72 lg:h-96 mt-8">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $chart])->html();
} elseif ($_instance->childHasBeenRendered('l2242822001-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2242822001-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2242822001-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2242822001-0');
} else {
    $response = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $chart]);
    $html = $response->html();
    $_instance->logRenderedChild('l2242822001-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    <?php else: ?>
        <div class="grid grid-cols-2 gap-4 mt-8">
            <?php $__currentLoopData = $villagesCharts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $villagesChart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col">
                    <div class="flex justify-center h-48 lg:h-72">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $villagesChart])->html();
} elseif ($_instance->childHasBeenRendered('chart'.e($key).'')) {
    $componentId = $_instance->getRenderedChildComponentId('chart'.e($key).'');
    $componentTag = $_instance->getRenderedChildComponentTagName('chart'.e($key).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('chart'.e($key).'');
} else {
    $response = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $villagesChart]);
    $html = $response->html();
    $_instance->logRenderedChild('chart'.e($key).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                    <p class="font-bold mx-auto"><?php echo e($key); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-span-2 grid grid-cols-4 gap-4">
                <?php $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $village): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex justify-center items-center space-x-4">
                        <div class="border w-4 h-4" style="background-color: #<?php echo e($village->color); ?>;"></div>
                        <p class="font-bold grow"><?php echo e($village->name); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button.success','data' => ['class' => 'mt-10','wire:click' => '$emit(\'openModal\', \'subcategory-modal\', '.e(json_encode(['id' => '', 'categoryId' => $category->id])).')']]); ?>
<?php $component->withName('button.success'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-10','wire:click' => '$emit(\'openModal\', \'subcategory-modal\', '.e(json_encode(['id' => '', 'categoryId' => $category->id])).')']); ?>+ Subategori <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\desacantiksijunjung\resources\views/livewire/subcategory.blade.php ENDPATH**/ ?>